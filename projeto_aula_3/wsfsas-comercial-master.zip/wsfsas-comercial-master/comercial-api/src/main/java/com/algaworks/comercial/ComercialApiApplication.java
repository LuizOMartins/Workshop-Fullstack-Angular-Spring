package com.algaworks.comercial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComercialApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComercialApiApplication.class, args);
	}

}

